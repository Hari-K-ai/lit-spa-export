# Part 1 – SPA Conversion using Lit

This project is a Single Page Application (SPA) built using Lit. It replicates the interactive visual animation from [Codrops Repeating Image Transition](https://tympanus.net/Development/RepeatingImageTransition/).

## ✅ What Was Built
- Full SPA structure using Lit and Vite
- The original animation logic was refactored into a reusable Lit component
- Routing handled with `@lit-labs/router` for seamless page navigation
- Clean modular layout with pages and components separated for scalability

## ✅ State Management
- State is handled using Lit’s reactive `@state()` and `@property()` decorators
- Local state per component keeps logic encapsulated
- Routing-based state transitions are managed via the `Router` API

## ✅ Storybook Integration
- Storybook was added via `storybook-web-components`
- Components like `<image-transition>` were tested and previewed in isolation
- This allowed UI iteration without affecting the main app flow

## ✅ Deployment
- Project built using **Vite** and deployed via **Cloudflare Pages**
- Static and frontend-only deployment, with responsive layout
- Deployment link is included in `cloudflare-deploy-link.txt`

## 🛠 Stack Used
- Lit Web Components
- Vite
- Tailwind CSS (optional styling)
- `@lit-labs/router`
- Storybook

## 📅 Interview Availability
- May 21, 10:00–12:00 IST
- May 22, 14:00–17:00 IST
- May 23, 11:00–13:00 IST

## 📦 Included Files
- `lit-spa-export.gz`: Git repo archive of the project
- `cloudflare-deploy-link.txt`: Deployed project link
- `README.md`: This explanation file
